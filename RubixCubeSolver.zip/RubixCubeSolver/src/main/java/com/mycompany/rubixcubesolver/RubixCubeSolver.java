/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.rubixcubesolver;
import javax.swing.JOptionPane;

public class RubixCubeSolver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String sequence="";
        String moveSequence;
        boolean edgesSolved=false;
        boolean cornersSolved=false;
        boolean parity;   
        String colors="worbgwbbbryyogryoryrywwgroyobgogbwrbwrwygbgooygw";
            /*enter in current state of unsolved cubes in the colors string. The format 
        consists of looking at the white-centered face, listing the colors by the first letter starting
        with the top left face and moving clockwise. Then move to the green-centered face, repeat,
        and continue for orange, blue, red, and finally yellow*/
            /*The following code forms an object for each face. Faces attached to a piece with two
            faces are edges, three, corners.*/
            EdgeFace eA=new EdgeFace('a',colors.charAt(1));
            EdgeFace eB=new EdgeFace('b',colors.charAt(3));
            EdgeFace eC=new EdgeFace('c',colors.charAt(5));
            EdgeFace eD=new EdgeFace('d',colors.charAt(7));
            EdgeFace eE=new EdgeFace('e',colors.charAt(9));
            EdgeFace eF=new EdgeFace('f',colors.charAt(11));
            EdgeFace eG=new EdgeFace('g',colors.charAt(13));
            EdgeFace eH=new EdgeFace('h',colors.charAt(15));
            EdgeFace eI=new EdgeFace('i',colors.charAt(17));
            EdgeFace eJ=new EdgeFace('j',colors.charAt(19));
            EdgeFace eK=new EdgeFace('k',colors.charAt(21));
            EdgeFace eL=new EdgeFace('l',colors.charAt(23));
            EdgeFace eM=new EdgeFace('m',colors.charAt(25));
            EdgeFace eN=new EdgeFace('n',colors.charAt(27));
            EdgeFace eO=new EdgeFace('o',colors.charAt(29));
            EdgeFace eP=new EdgeFace('p',colors.charAt(31));
            EdgeFace eQ=new EdgeFace('q',colors.charAt(33));
            EdgeFace eR=new EdgeFace('r',colors.charAt(35));
            EdgeFace eS=new EdgeFace('s',colors.charAt(37));
            EdgeFace eT=new EdgeFace('t',colors.charAt(39));
            EdgeFace eU=new EdgeFace('u',colors.charAt(41));
            EdgeFace eV=new EdgeFace('v',colors.charAt(43));
            EdgeFace eW=new EdgeFace('w',colors.charAt(45));
            EdgeFace eX=new EdgeFace('x',colors.charAt(47));
            CornerFace cA=new CornerFace('a',colors.charAt(0));
            CornerFace cB=new CornerFace('b',colors.charAt(2));
            CornerFace cC=new CornerFace('c',colors.charAt(4));            
            CornerFace cD=new CornerFace('d',colors.charAt(6));            
            CornerFace cE=new CornerFace('e',colors.charAt(8));
            CornerFace cF=new CornerFace('f',colors.charAt(10));
            CornerFace cG=new CornerFace('g',colors.charAt(12));
            CornerFace cH=new CornerFace('h',colors.charAt(14));
            CornerFace cI=new CornerFace('i',colors.charAt(16));
            CornerFace cJ=new CornerFace('j',colors.charAt(18));
            CornerFace cK=new CornerFace('k',colors.charAt(20));
            CornerFace cL=new CornerFace('l',colors.charAt(22));
            CornerFace cM=new CornerFace('m',colors.charAt(24));
            CornerFace cN=new CornerFace('n',colors.charAt(26));
            CornerFace cO=new CornerFace('o',colors.charAt(28));
            CornerFace cP=new CornerFace('p',colors.charAt(30));
            CornerFace cQ=new CornerFace('q',colors.charAt(32));
            CornerFace cR=new CornerFace('r',colors.charAt(34));
            CornerFace cS=new CornerFace('s',colors.charAt(36));
            CornerFace cT=new CornerFace('t',colors.charAt(38));
            CornerFace cU=new CornerFace('u',colors.charAt(40));
            CornerFace cV=new CornerFace('v',colors.charAt(42));
            CornerFace cW=new CornerFace('w',colors.charAt(44));
            CornerFace cX=new CornerFace('x',colors.charAt(46));

            
        //Then, the two edges or three corners are all attatched to one object representing that piece
        Edge ea=new Edge(eA,eQ);
        Edge eq=new Edge(eQ,eA);
        Edge eb=new Edge(eB,eM);
        Edge em=new Edge(eM,eB);
        Edge ec=new Edge(eC,eI);
        Edge ei=new Edge(eI,eC);
        Edge ed=new Edge(eD,eE);
        Edge ee=new Edge(eE,eD);
        Edge ej=new Edge(eJ,eP);
        Edge ep=new Edge(eP,eJ);
        Edge en=new Edge(eN,eT);
        Edge et=new Edge(eT,eN);
        Edge er=new Edge(eR,eH);
        Edge eh=new Edge(eH,eR);
        Edge ef=new Edge(eF,eL);
        Edge el=new Edge(eL,eF);
        Edge eu=new Edge(eU,eK);
        Edge ek=new Edge(eK,eU);
        Edge ev=new Edge(eV,eO);
        Edge eo=new Edge(eO,eV);
        Edge ew=new Edge(eW,eS);
        Edge es=new Edge(eS,eW);
        Edge ex=new Edge(eX,eG);
        Edge eg=new Edge(eG,eX);
        Corner ca=new Corner(cA,cE,cR);
        Corner ce=new Corner(cE,cA,cR);
        Corner cr=new Corner(cR,cE,cA);
        Corner cb=new Corner(cB,cN,cQ);
        Corner cn=new Corner(cN,cB,cQ);
        Corner cq=new Corner(cQ,cB,cN);
        Corner cc=new Corner(cC,cJ,cM);
        Corner cj=new Corner(cJ,cC,cM);
        Corner cm=new Corner(cM,cC,cJ);
        Corner cd=new Corner(cD,cI,cF);
        Corner ci=new Corner(cI,cD,cF);
        Corner cf=new Corner(cF,cD,cI);
        Corner cu=new Corner(cU,cL,cG);
        Corner cl=new Corner(cL,cU,cG);
        Corner cg=new Corner(cG,cU,cL);
        Corner cv=new Corner(cV,cK,cP);
        Corner ck=new Corner(cK,cV,cP);
        Corner cp=new Corner(cP,cV,cK);
        Corner cw=new Corner(cW,cO,cT);
        Corner co=new Corner(cO,cT,cW);
        Corner ct=new Corner(cT,cW,cO);
        Corner cx=new Corner(cX,cH,cS);
        Corner ch=new Corner(cH,cX,cS);
        Corner cs=new Corner(cS,cX,cH);
        Edge edges[]={ea,eb,ec,ed,ee,ef,eg,eh,ei,ej,ek,el,em,en,eo,ep,eq,er,es,et,eu,ev,ew,ex};
        
        edgeComplements(edges);
        String nextPos="b";
        String reset1="b";
        String reset2="m";
        //This section produces a sequence of letters which represents a solution
        for(Edge i:edges){
            if(i.n1.position.equals(i.correctPos)){
                i.solved=true;
            }
        }
        a:while(true){
            nextPos=getEdgeNextLetter(nextPos,edges);
            b:if(nextPos.equals(reset1)||nextPos.equals(reset2)){
                if(!(nextPos.equals("b")||nextPos.equals("m"))){
                    sequence+=nextPos;
                }
                for(Edge i:edges){
                    if(i==eb||i==em){
                        continue;}
                    if(!i.solved){
                        nextPos=i.n1.position;
                        reset1=i.n1.position;
                        reset2=i.n2.position;
                        break b;
                    }
                }break;
            }sequence+=nextPos;
            System.out.println(sequence);
        }parity=(sequence.length()%2==1);
        System.out.println(parity);
        System.out.println("Edges solved: "+sequence);
        sequence+=" ";
        moveSequence=getEdgeMoveSequence(parity,sequence);
        System.out.println("Move Sequence: "+moveSequence);
        Corner[] corners={ca,cb,cc,cd,ce,cf,cg,ch,ci,cj,ck,cl,cm,cn,co,cp,cq,cr,cs,ct,cu,cv,cw,cx};
        cornerComplements(corners);
        nextPos="r";
        reset1="r";reset2="a";String reset3="e";
        String cSequence="";
        a:while(true){
            nextPos=getCornerNextLetter(nextPos,corners);
            b:if(nextPos.equals(reset1)||nextPos.equals(reset2)||nextPos.equals(reset3)){
                if(!(nextPos.equals("r")||nextPos.equals("a")||nextPos.equals("e"))){
                    cSequence+=nextPos;
                }
                for(Corner i:corners){
                    if(i==cr||i==ce||i==ca){
                        continue;}
                    if(!i.solved){
                        nextPos=i.n1.position;
                        reset1=i.n1.position;
                        reset2=i.n2.position;
                        reset3=i.n3.position;
                        break b;
                    }
                }break;
            }cSequence+=nextPos;
            System.out.println(cSequence);
        }
        moveSequence+=getCornerMoveSequence(cSequence);
        System.out.println(sequence+cSequence);
        System.out.println("Final sequence: "+moveSequence);
    }
    public static String getEdgeNextLetter(String correctPos,Edge[] e){
        char ch = correctPos.charAt(0);
        int pos = ch - 'a';
        e[pos].solved=true;
        e[pos].complement.solved=true;
        return e[pos].correctPos;
    }
    public static void edgeComplements(Edge[] e){
        for(Edge i:e){
            for(Edge j:e){
                if(i.n1==j.n2){
                    i.complement=j;
                }
            }
        }
    }
    public static String getCornerNextLetter(String correctPos,Corner[] c){
        char ch = correctPos.charAt(0);
        int pos = ch - 'a';
        c[pos].solved=true;
        c[pos].complements[0].solved=true;
        c[pos].complements[1].solved=true;
        return c[pos].correctPos;
    }
    public static void cornerComplements(Corner[] c){
        int count;
        for(Corner i:c){
            count=0;
            System.out.println(i.correctPos);
            for(Corner j:c){
                if((i.n1==j.n2||i.n1==j.n3)&&(i.n2==j.n1||i.n2==j.n2||i.n2==j.n3)&&(i.n3==j.n1||i.n3==j.n2||i.n3==j.n3)){
                    i.complements[count]=j;
                    count++;
                }
            }
        }
    }
    /*getEdgeMoveSequence and getCornerMoveSequence convert the solution sequence which consists of 15-25 letters
    to an actual sequence of turns*/
    public static String getEdgeMoveSequence(boolean parity, String s){
        String moveSequence="";
        String tPerm="R U R' U' R' F R2 U' R' U' R U R' F' ";
        for(int i=0;i<s.length();i++){
            switch(s.charAt(i)){
                case 'a':moveSequence+=("l2 D' l2 "+tPerm+"l2 D l2 ");break;
                case 'c':moveSequence+=("l2 D l2 "+tPerm+"l2 D' l2 ");break;
                case 'd':moveSequence+=(tPerm);break;
                case 'e':moveSequence+=("L d' L "+tPerm+"L' d L' ");break;
                case 'f':moveSequence+=("d' L "+tPerm+"L' d ");break;
                case 'g':moveSequence+=("L' d' L "+tPerm+"L' d L ");break;
                case 'h':moveSequence+=("d L' "+tPerm+"L d' ");break;
                case 'i':moveSequence+=("l D' L2 "+tPerm+"L2 D l' ");break;
                case 'j':moveSequence+=("d2 L "+tPerm+"L' d2 ");break;
                case 'k':moveSequence+=("l D l2 "+tPerm+"l2 D' l' ");break;
                case 'l':moveSequence+=("L' "+tPerm+"L ");break;
                case 'n':moveSequence+=("d L "+tPerm+"L' d' ");break;
                case 'o':moveSequence+=("D' l D L2 "+tPerm+"L2 D' l' D ");break;
                case 'p':moveSequence+=("d' L' "+tPerm+"L d ");break;
                case 'q':moveSequence+=("l' D L2 "+tPerm+"L2 D' l ");break;
                case 'r':moveSequence+=("L "+tPerm+"L' ");break;
                case 's':moveSequence+=("l' D' L2 "+tPerm+"L2 D l ");break;
                case 't':moveSequence+=("d2 L' "+tPerm+"L d2 ");break;
                case 'u':moveSequence+=("D' L2 "+tPerm+"L2 D ");break;
                case 'v':moveSequence+=("D2 L2 "+tPerm+"L2 D2 ");break;
                case 'w':moveSequence+=("D L2 "+tPerm+"L2 D' ");break;
                case 'x':moveSequence+=("L2 "+tPerm+"L2 ");break;
                   
            }
        }if(parity){
            moveSequence+="R U' R' U' R U R D R' U' R D' R' U2 R' U' ";
        }return moveSequence;
    }
    public static String getCornerMoveSequence(String s){
        String moveSequence="";
        String jPerm="R U' R' U' R U R' F' R U R' U' R' F R ";
        for(int i=0;i<s.length();i++){
            switch(s.charAt(i)){
                case 'b':moveSequence+=("R' F "+jPerm+"F' R ");break;
                case 'c':moveSequence+=("R' "+jPerm+"R ");break;
                case 'd':moveSequence+=("F' D "+jPerm+"D' F ");break;
                case 'f':moveSequence+=("F R' "+jPerm+"R F' ");break;
                case 'g':moveSequence+=("D "+jPerm+"D' ");break;
                case 'h':moveSequence+=("D F' "+jPerm+"F D' ");break;
                case 'i':moveSequence+=("F2 "+jPerm+"F2 ");break;
                case 'j':moveSequence+=("F "+jPerm+"F' ");break;
                case 'k':moveSequence+=(jPerm);break;
                case 'l':moveSequence+=("F' "+jPerm+"F ");break;
                case 'm':moveSequence+=("R2 D' "+jPerm+"D R2 ");break;
                case 'n':moveSequence+=("R D' "+jPerm+"D R' ");break;
                case 'o':moveSequence+=("D' "+jPerm+"D ");break;
                case 'p':moveSequence+=("R' D' "+jPerm+"D R ");break;
                case 'q':moveSequence+=("R2 "+jPerm+"R2 ");break;
                case 's':moveSequence+=("D2 "+jPerm+"D2 ");break;
                case 't':moveSequence+=("D2 F' "+jPerm+"F D2 ");break;
                case 'u':moveSequence+=("D2 R "+jPerm+"R' D2 ");break;
                case 'v':moveSequence+=("D R "+jPerm+"R' D' ");break;
                case 'w':moveSequence+=("R "+jPerm+"R' ");break;
                case 'x':moveSequence+=("D' R "+jPerm+"R' D ");break;
                   
            }
        }return moveSequence;
    }
}
class Face{
    public Face(char p,char c){
        position=String.valueOf(p);
        color=String.valueOf(c);
    }
    String position;
    String color;
   
}
class CornerFace extends Face{
    
    public CornerFace(char p,char c){
        super(p,c);
    }
}

class EdgeFace extends Face{
    
    public EdgeFace(char p,char c){
        super(p,c);
    }
}
class Edge{
    public Edge(EdgeFace a,EdgeFace b){
        solved=false;
        n1=a;
        n2=b;
        switch(n1.color){
            case "w":
            switch(n2.color){
                case "g":
                correctPos="c";break;
                case "o":
                correctPos="d";break;
                case "b":
                correctPos="a";break;
                case "r":
                correctPos="b";break;
            }break;
            case "g":
            switch(n2.color){
                case "w":
                correctPos="i";break;
                case "o":
                correctPos="l";break;
                case "y":
                correctPos="k";break;
                case "r":
                correctPos="j";break;
            }break;
            case "o":
            switch(n2.color){
                case "w":
                correctPos="e";break;
                case "b":
                correctPos="h";break;
                case "y":
                correctPos="g";break;
                case "g":
                correctPos="f";break;
            }break;
            case "b":
            switch(n2.color){
                case "w":
                correctPos="q";break;
                case "o":
                correctPos="r";break;
                case "y":
                correctPos="s";break;
                case "r":
                correctPos="t";break;
            }break;
            case "r":
            switch(n2.color){
                case "w":
                correctPos="m";break;
                case "g":
                correctPos="p";break;
                case "y":
                correctPos="o";break;
                case "b":
                correctPos="n";break;
            }break;
            case "y":
            switch(n2.color){
                case "g":
                correctPos="u";break;
                case "o":
                correctPos="x";break;
                case "b":
                correctPos="w";break;
                case "r":
                correctPos="v";break;
            }break;
           
        }
    }
    EdgeFace n1;
    EdgeFace n2;
    String correctPos;
    boolean solved;
    Edge complement;
}
class Corner{
    public Corner(CornerFace a,CornerFace b,CornerFace c){
        solved=false;
        n1=a;
        n2=b;
        n3=c;
        switch(n1.color){
            case "w":
            switch(n2.color){
                case "g":
                switch(n3.color){
                    case "o":correctPos="d";break;
                    case "r":correctPos="c";break;
                }break;
                case "o":
                switch(n3.color){
                    case "b":correctPos="a";break;
                    case "g":correctPos="d";break;
                }break;
                case "b":
                switch(n3.color){
                    case "o":correctPos="a";break;
                    case "r":correctPos="b";break;
                }break;
                case "r":
                switch(n3.color){
                    case "b":correctPos="b";break;
                    case "g":correctPos="c";break;
                }break;
            }break;
            case "y":
            switch(n2.color){
                case "g":
                switch(n3.color){
                    case "o":correctPos="u";break;
                    case "r":correctPos="v";break;
                }break;
                case "o":
                switch(n3.color){
                    case "b":correctPos="x";break;
                    case "g":correctPos="u";break;
                }break;
                case "b":
                switch(n3.color){
                    case "o":correctPos="x";break;
                    case "r":correctPos="w";break;
                }break;
                case "r":
                switch(n3.color){
                    case "b":correctPos="w";break;
                    case "g":correctPos="v";break;
                }break;
            }break;
            case "r":
            switch(n2.color){
                case "g":
                switch(n3.color){
                    case "y":correctPos="p";break;
                    case "w":correctPos="m";break;
                }break;
                case "w":
                switch(n3.color){
                    case "b":correctPos="n";break;
                    case "g":correctPos="m";break;
                }break;
                case "b":
                switch(n3.color){
                    case "w":correctPos="n";break;
                    case "y":correctPos="o";break;
                }break;
                case "y":
                switch(n3.color){
                    case "b":correctPos="o";break;
                    case "g":correctPos="p";break;
                }break;
            }break;
            case "o":
            switch(n2.color){
                case "g":
                switch(n3.color){
                    case "y":correctPos="g";break;
                    case "w":correctPos="f";break;
                }break;
                case "w":
                switch(n3.color){
                    case "b":correctPos="e";break;
                    case "g":correctPos="f";break;
                }break;
                case "b":
                switch(n3.color){
                    case "w":correctPos="e";break;
                    case "y":correctPos="h";break;
                }break;
                case "y":
                switch(n3.color){
                    case "b":correctPos="h";break;
                    case "g":correctPos="g";break;
                }break;
            }break;
            case "b":
            switch(n2.color){
                case "w":
                switch(n3.color){
                    case "o":correctPos="r";break;
                    case "r":correctPos="q";break;
                }break;
                case "o":
                switch(n3.color){
                    case "y":correctPos="s";break;
                    case "w":correctPos="r";break;
                }break;
                case "y":
                switch(n3.color){
                    case "o":correctPos="s";break;
                    case "r":correctPos="t";break;
                }break;
                case "r":
                switch(n3.color){
                    case "w":correctPos="q";break;
                    case "y":correctPos="t";break;
                }break;
            }break;
            case "g":
            switch(n2.color){
                case "w":
                switch(n3.color){
                    case "o":correctPos="i";break;
                    case "r":correctPos="j";break;
                }break;
                case "o":
                switch(n3.color){
                    case "w":correctPos="i";break;
                    case "y":correctPos="l";break;
                }break;
                case "y":
                switch(n3.color){
                    case "o":correctPos="l";break;
                    case "r":correctPos="k";break;
                }break;
                case "r":
                switch(n3.color){
                    case "w":correctPos="j";break;
                    case "y":correctPos="k";break;
                }break;
            }break;
            
           
        }
    }
    CornerFace n1;
    CornerFace n2;
    CornerFace n3;
    String correctPos;
    boolean solved;
    Corner[] complements=new Corner[2];
}